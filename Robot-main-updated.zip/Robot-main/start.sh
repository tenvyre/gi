#!/usr/bin/env bash
# Starts the pump backend and opens the controller UI.
#
#   bash start.sh            -> simulated Arduino on the TV (Termux); auto-detect on a laptop
#   bash start.sh mock       -> simulated Arduino (no hardware)
#   bash start.sh termux     -> REAL Arduino over USB from Termux (Android TV / phone)
#   bash start.sh serial     -> REAL Arduino via a normal serial port (laptop)
#   bash start.sh probe      -> (Termux) show what USB devices Android can see
#   bash start.sh setup      -> only create .venv and install every library, then exit
#   bash start.sh --reinstall [mode]  -> force a clean library reinstall first
#   bash start.sh --browser firefox   -> skip the question: chrome | firefox | default
#   bash start.sh help       -> list every command, option and environment variable
#
# First run creates a private Python virtualenv in .venv, activates it, and installs
# everything from requirements*.txt via deps.py. Later runs only re-check (fast) and
# automatically install anything that is missing or newly added.
#
# All output is captured to logs/ so nothing is lost if the terminal closes.

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$DIR"
mkdir -p logs
RUN_LOG="logs/start_$(date +"%Y%m%d_%H%M%S").log"
PORT="${PUMP_PORT:-5005}"

log() { echo "[$(date +%T)] $*" | tee -a "$RUN_LOG"; }

is_termux() { [ -n "${TERMUX_VERSION:-}" ] || [[ "${PREFIX:-}" == *com.termux* ]]; }

show_help() {
cat <<'HELP'
CODA start script

USAGE
  bash start.sh [options] [mode]

MODES (what talks to the pumps)
  (none)            Termux: simulated Arduino.  Laptop: auto-detect the Arduino's serial port
  mock              Simulated Arduino, no hardware needed
  auto | serial     Real Arduino on a normal serial port (laptop)
  termux            Real Arduino over USB from Termux (Android TV / phone)
  probe             Termux: list the USB devices Android can see, then exit
  setup             Create .venv and install every library, then exit (no backend started)

OPTIONS
  help, -h, --help  Show this text
  --browser NAME    Browser for ChatGPT and the AI browser, without asking:
                      default  the operating system's default browser (auto-detected)
                      chrome   Google Chrome / Chromium / Edge
                      firefox  Mozilla Firefox
  --ask             Ask which browser even if a choice is saved or CODA_BROWSER is set
  --no-ask          Never ask; use --browser / CODA_BROWSER / your last choice (default: default)
  --reinstall       Force a clean reinstall of every library before starting

BROWSER QUESTION
  Interactive runs ask which browser to use. Press Enter to keep your last choice.
  The answer is remembered in .coda_browser and passed on as CODA_BROWSER.

EXAMPLES
  bash start.sh                     start (asks for the browser)
  bash start.sh mock --no-ask       simulated Arduino, no questions
  bash start.sh termux --browser firefox
  bash start.sh setup               install everything only
  bash start.sh --reinstall mock

ENVIRONMENT VARIABLES (all optional)
  Backend     PUMP_TRANSPORT  PUMP_HOST  PUMP_PORT (5005)  PUMP_SERIAL_PORT  FLOW_SENSOR_PORT  PUMP_USB_DEVICE
  AI          GROQ_API_KEY  GROQ_PROXY  OMNIROUTE_BASE_URL  ELEVENLABS_API_KEY  ELEVENLABS_VOICE_ID
  Browser     CODA_BROWSER (default|chrome|firefox)  CHATGPT_BROWSER (path to the binary)  CHATGPT_HEADLESS (1|0)
  ChatGPT     CHATGPT_URL  CHATGPT_DRIVER (playwright|cdp)  CHATGPT_CAPTURE (auto|dom|screenshot)
              CHATGPT_TIMEOUT (seconds, default 75)  CHATGPT_DEBUG_DIR (save the screenshot it analysed)
              CHATGPT_CDP_URL  CHATGPT_BRIDGE_URL  CHATGPT_BRIDGE_TOKEN
  AI browser  BROWSER_ENGINE (auto|full|lite)  BROWSER_REMOTE  BROWSER_TOKEN  BROWSER_ALLOW_PRIVATE
  Setup       SKIP_DEPS_CHECK=1  SKIP_BROWSER_DOWNLOAD=1  SKIP_CHROMIUM=1

PORTABLE (USB stick)
  Everything lives in this folder: data/ (API keys, settings, ChatGPT login), .venv-<os>/ (libraries, one per
  operating system), logs/. Copy or carry the whole folder. Python itself must be installed on each computer.
  Use `bash start.sh` (FAT/exFAT sticks can't mark files executable, so ./start.sh may be refused).

AFTER IT STARTS
  Kiosk  http://localhost:5005/     Pump test  /test     LCD settings  /display     Logs  logs/
  Stop with Ctrl+C (not Ctrl+Z).   Termux shortcut after termux_setup.sh:  coda [mode]
HELP
}

FORCE_DEPS=""; ASK=1; BROWSER_ARG=""; MODE_ARG=""
while [ $# -gt 0 ]; do
  case "$1" in
    help|-h|--help) show_help; exit 0 ;;
    --reinstall) FORCE_DEPS="--force" ;;
    --browser) BROWSER_ARG="${2:-}"; shift ;;
    --browser=*) BROWSER_ARG="${1#*=}" ;;
    --ask) ASK=2 ;;
    --no-ask) ASK=0 ;;
    -*) echo "Unknown option: $1   (try: bash start.sh help)"; exit 1 ;;
    *) MODE_ARG="$1" ;;
  esac
  shift
done
set -- ${MODE_ARG:+"$MODE_ARG"}

# ---------------- Python venv + automatic library checker ----------------
if is_termux && ! command -v python >/dev/null 2>&1 && ! command -v python3 >/dev/null 2>&1; then
  log "Installing Python (pkg)..."; pkg install -y python || true
fi
PY0=""
for c in python3 python; do command -v "$c" >/dev/null 2>&1 && { PY0="$c"; break; }; done
if [ -z "$PY0" ]; then
  echo "Python 3 was not found. Install it (Debian/Ubuntu: sudo apt install python3 python3-venv; macOS: brew install python; Termux: pkg install python)."
  exit 1
fi

# ---------------- which browser for ChatGPT + the AI browser? ----------------
normalize_browser() {
  case "$(echo "$1" | tr 'A-Z' 'a-z')" in
    1|default|auto|system|"") echo auto ;;
    2|chrome|chromium|edge|google-chrome) echo chrome ;;
    3|firefox|ff) echo firefox ;;
    *) echo "" ;;
  esac
}
SAVED=""; [ -f "$DIR/.coda_browser" ] && SAVED="$(normalize_browser "$(cat "$DIR/.coda_browser" 2>/dev/null)")"
CHOICE=""
if [ -n "$BROWSER_ARG" ]; then
  CHOICE="$(normalize_browser "$BROWSER_ARG")"
  [ -z "$CHOICE" ] && { echo "Unknown browser '$BROWSER_ARG' (use default, chrome or firefox)."; exit 1; }
elif [ -n "${CODA_BROWSER:-}" ] && [ "$ASK" != 2 ]; then
  CHOICE="$(normalize_browser "$CODA_BROWSER")"
elif [ "$ASK" != 0 ] && [ -t 0 ] && [ -t 1 ]; then
  INFO="$("$PY0" "$DIR/coda_browser.py" --detect 2>/dev/null)"
  D_DEF="$(echo "$INFO" | sed -n 's/.*default=\([^ ]*\).*/\1/p')"
  D_CH="$(echo "$INFO" | sed -n 's/.*chrome=\([^ ]*\).*/\1/p')"
  D_FF="$(echo "$INFO" | sed -n 's/.*firefox=\([^ ]*\).*/\1/p')"
  [ "$D_CH" = "-" ] && D_CH="not installed" ; [ "$D_FF" = "-" ] && D_FF="not installed"
  case "$SAVED" in firefox) DEFNUM=3 ;; chrome) DEFNUM=2 ;; *) DEFNUM=1 ;; esac
  echo
  echo "Which browser should ChatGPT and the AI browser use?"
  echo "  1) System default browser   (detected: ${D_DEF:-unknown})"
  echo "  2) Google Chrome / Chromium (${D_CH:-not installed})"
  echo "  3) Mozilla Firefox          (${D_FF:-not installed})"
  printf "Choose 1-3 [Enter = %s]: " "$DEFNUM"
  read -r ANS || ANS=""
  [ -z "$ANS" ] && ANS="$DEFNUM"
  CHOICE="$(normalize_browser "$ANS")"
  [ -z "$CHOICE" ] && { echo "Not understood, using the system default."; CHOICE=auto; }
else
  CHOICE="${SAVED:-auto}"
fi
export CODA_BROWSER="$CHOICE"
echo "$CHOICE" > "$DIR/.coda_browser" 2>/dev/null || true
log "Browser for ChatGPT / AI browser: $( [ "$CHOICE" = auto ] && echo 'system default' || echo "$CHOICE" )"

# One virtualenv per operating system (a venv can't be shared between Windows / Linux / macOS / Termux), so the
# same folder on a USB stick works on every machine: .venv-win, .venv-linux, .venv-mac, .venv-termux.
case "$(uname -s 2>/dev/null)" in
  Darwin) OSTAG=mac ;;
  *) if is_termux; then OSTAG=termux; else OSTAG=linux; fi ;;
esac
VENV="$DIR/.venv-$OSTAG"
if [ -x "$VENV/bin/python" ] && ! "$VENV/bin/python" -c "import sys" >/dev/null 2>&1; then
  log "The virtualenv is broken (Python moved?) — recreating it."
  rm -rf "$VENV"
fi
if [ ! -x "$VENV/bin/python" ]; then
  log "Creating virtualenv in .venv-$OSTAG (first run on this computer) ..."
  if ! "$PY0" -m venv --copies "$VENV" >> "$RUN_LOG" 2>&1; then      # --copies: FAT/exFAT sticks have no symlinks
    rm -rf "$VENV"
    echo "Could not create a virtualenv. On Debian/Ubuntu run:  sudo apt install python3-venv   (then retry)."
    echo "If the drive is read-only or full, copy the folder to a writable place."
    exit 1
  fi
fi
# shellcheck disable=SC1091
. "$VENV/bin/activate"        # automatic enabler: everything below runs inside .venv
PY="$VENV/bin/python"
DEPS_ARGS="$FORCE_DEPS"
log "Checking libraries..."
"$PY" "$DIR/deps.py" $DEPS_ARGS 2>&1 | tee -a "$RUN_LOG"
if [ "${PIPESTATUS[0]}" -ne 0 ]; then
  echo "Library setup failed — see above."; exit 1
fi

if is_termux; then DEFAULT_MODE=mock; else DEFAULT_MODE=auto; fi
MODE="${1:-${PUMP_TRANSPORT:-$DEFAULT_MODE}}"
if [ "$MODE" = "auto" ] && is_termux; then MODE=termux; fi

# ---------------- Termux USB helpers ----------------

need_termux_usb() {
  if ! command -v termux-usb >/dev/null 2>&1; then
    echo ""
    echo "termux-usb isn't installed. One-time setup:"
    echo "  1. Install the 'Termux:API' app (same source you got Termux from, e.g. F-Droid)"
    echo "  2. In Termux run:   pkg install termux-api libusb python"
    echo "Then run this again."
    exit 1
  fi
}

usb_devices() {
  termux-usb -l 2>/dev/null | $PY -c '
import sys, json
try:
    for d in json.load(sys.stdin): print(d)
except Exception:
    pass'
}

make_wrapper() {   # $1 = file to write, $2 = the command it should exec
  printf '#!%s/bin/bash\nexec %s "$@"\n' "$PREFIX" "$2" > "$1"
  chmod +x "$1"
}

probe_device() {   # $1 = usb device path
  make_wrapper "$DIR/.usb_probe.sh" "$PY $DIR/usb_transport.py --probe"
  termux-usb -r -e "$DIR/.usb_probe.sh" "$1" 2>&1
}

pick_usb_device() {
  if [ -n "${PUMP_USB_DEVICE:-}" ]; then echo "$PUMP_USB_DEVICE"; return; fi
  mapfile -t DEVS < <(usb_devices)
  if [ "${#DEVS[@]}" -eq 0 ]; then
    echo "" >&2
    echo "Android reports no USB devices. Check: OTG/USB cable, Arduino plugged in," >&2
    echo "and that nothing else (like ArduinoDroid) is holding it." >&2
    return 1
  fi
  if [ "${#DEVS[@]}" -eq 1 ]; then echo "${DEVS[0]}"; return; fi

  echo "Several USB devices found — checking which one is the Arduino..." >&2
  for d in "${DEVS[@]}"; do
    echo "  probing $d (tap OK if Android asks)" >&2
    if probe_device "$d" | grep -q "ARDUINO=yes"; then echo "$d"; return; fi
  done
  echo "Couldn't tell automatically. Devices:" >&2
  i=1; for d in "${DEVS[@]}"; do echo "  $i) $d" >&2; i=$((i+1)); done
  read -r -p "Which number is the Arduino? " n
  echo "${DEVS[$((n-1))]}"
}

# ---------------- probe mode ----------------

if [ "$MODE" = "setup" ]; then
  log "Setup complete. Start the robot with: bash start.sh"
  exit 0
fi

if [ "$MODE" = "probe" ] || [ "$MODE" = "termux" ]; then
  "$PY" "$DIR/deps.py" --usb 2>&1 | tee -a "$RUN_LOG" >/dev/null
fi

if [ "$MODE" = "probe" ]; then
  need_termux_usb
  mapfile -t DEVS < <(usb_devices)
  [ "${#DEVS[@]}" -eq 0 ] && { echo "No USB devices visible to Termux."; exit 1; }
  for d in "${DEVS[@]}"; do
    echo "=== $d ==="
    probe_device "$d"
    echo ""
  done
  exit 0
fi

# ---------------- launch ----------------

export PUMP_TRANSPORT="$MODE"
log "Transport mode: $MODE"

if [ "$MODE" = "termux" ]; then
  need_termux_usb
  DEV="$(pick_usb_device)" || exit 1
  log "Using USB device: $DEV"
  log ">>> If Android shows a USB permission popup, tap OK <<<"
  make_wrapper "$DIR/.usb_launch.sh" "$PY $DIR/backend.py"
  termux-usb -r -e "$DIR/.usb_launch.sh" "$DEV" >> "$RUN_LOG" 2>&1 &
else
  "$PY" backend.py >> "$RUN_LOG" 2>&1 &
fi
BACKEND_PID=$!
log "Backend started (PID $BACKEND_PID)"

# Stop everything on exit/Ctrl+C. (In termux mode the real server is a child
# of termux-usb, so kill by name too — otherwise it keeps port $PORT busy.)
cleanup() {
  log "Stopping backend..."
  kill "$BACKEND_PID" 2>/dev/null
  pkill -f "backend.py" 2>/dev/null
}
trap cleanup EXIT

log "Waiting for the backend to respond..."
UP=0
for i in $(seq 1 60); do
  if "$PY" -c "import urllib.request,sys;urllib.request.urlopen('http://localhost:${PORT}/hardware',timeout=1)" >/dev/null 2>&1; then UP=1; break; fi
  sleep 0.5
done

if [ "$UP" -ne 1 ]; then
  log "The backend did not start. Last lines of the log:"
  tail -n 15 "$RUN_LOG"
  exit 1
fi
log "Backend is up."

# Say in plain words what the Arduino link looks like
"$PY" -c "import urllib.request;print(urllib.request.urlopen('http://localhost:${PORT}/hardware',timeout=3).read().decode())" 2>/dev/null | "$PY" -c '
import sys, json
try:
    h = json.load(sys.stdin)
except Exception:
    sys.exit()
if h.get("mock"):
    print("  Arduino: SIMULATED (no hardware in use)")
elif h.get("connected"):
    print("  Arduino: CONNECTED  ->  " + str(h.get("detail")))
else:
    print("  Arduino: NOT FOUND  ->  " + str(h.get("error")))
' | tee -a "$RUN_LOG"

URL="http://localhost:${PORT}/"
log "Opening controller UI: $URL"
if command -v termux-open-url >/dev/null 2>&1; then
  termux-open-url "$URL" >/dev/null 2>&1
elif command -v xdg-open >/dev/null 2>&1; then
  xdg-open "$URL" >/dev/null 2>&1
elif command -v open >/dev/null 2>&1; then
  open "$URL"
else
  echo "Could not auto-open a browser — open this manually: $URL"
fi

echo ""
echo "Controller UI:   $URL"
echo "Test dashboard:  ${URL}test"
echo "Run log:         $RUN_LOG"
echo "Server log:      logs/server.log"
echo ""
echo "Press Ctrl+C to stop (not Ctrl+Z)."

wait "$BACKEND_PID"
