# Everything the backend remembers lives here (ai_settings.json, browser_storage.json, chatgpt_profile/).
# Copy this folder with the project to keep your keys and settings. It contains API keys in plain text -
# keep the drive private. Delete the folder to reset everything.
