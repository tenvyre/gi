#!/data/data/com.termux/files/usr/bin/bash
# One-shot installer for running the robot fully inside Termux.
#   bash termux_setup.sh              core only (simulated Arduino, Groq/ElevenLabs etc.)
#   bash termux_setup.sh --chatgpt    + Chromium for the ChatGPT website provider (fully standalone)
#   bash termux_setup.sh --usb        + real Arduino over USB (termux-usb)
#   bash termux_setup.sh --all        everything
# Safe to re-run.
set -e
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CHATGPT=0; USB=0
for a in "$@"; do
  case "$a" in
    --chatgpt) CHATGPT=1 ;;
    --usb) USB=1 ;;
    --all) CHATGPT=1; USB=1 ;;
    -h|--help) sed -n 2,8p "$0"; exit 0 ;;
    *) echo "Unknown option: $a"; exit 1 ;;
  esac
done

if [ -z "${TERMUX_VERSION:-}" ] && [[ "${PREFIX:-}" != *com.termux* ]]; then
  echo "This script is for Termux on Android."; exit 1
fi

echo "==> Updating packages"
pkg update -y && pkg upgrade -y

echo "==> Core packages"
pkg install -y python git unzip curl

echo "==> Python virtualenv + libraries (automatic)"
[ "$CHATGPT" = 1 ] || export SKIP_CHROMIUM=1
[ "$USB" = 1 ] && pkg install -y termux-api libusb || true
cd "$DIR" && bash start.sh setup
if [ "$CHATGPT" = 1 ]; then
  echo "   Chromium runs headless inside Termux; sign in via Settings > System > 'Open ChatGPT browser'."
fi

echo "==> Creating the 'coda' launcher"
mkdir -p "$HOME/bin"
cat > "$HOME/bin/coda" <<LAUNCH
#!/data/data/com.termux/files/usr/bin/bash
command -v termux-wake-lock >/dev/null 2>&1 && termux-wake-lock
cd "$DIR" && exec bash start.sh "\$@"
LAUNCH
chmod +x "$HOME/bin/coda"
case ":$PATH:" in *":$HOME/bin:"*) ;; *)
  grep -q 'HOME/bin' "$HOME/.bashrc" 2>/dev/null || echo 'export PATH="$HOME/bin:$PATH"' >> "$HOME/.bashrc"
  export PATH="$HOME/bin:$PATH" ;;
esac

echo
echo "Done. Start the robot with:   coda          (simulated Arduino)"
echo "                              coda termux   (real Arduino over USB)"
echo "Then open http://localhost:5005 in the device's browser."
