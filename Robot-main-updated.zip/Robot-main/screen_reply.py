"""Screenshot analyzer: pull out ONLY ChatGPT's reply from a picture of the page.

Used as the fallback of chatgpt_web.py when reading the page's text fails (ChatGPT changed its
markup, text is virtualised, etc.). Pipeline:

  1. decode the PNG (Pillow if installed, otherwise a built-in pure-Python decoder)
  2. work out the *reply region*:
       - vertical limits: below the user's message bubble, above the composer (hints from page
         geometry when available, otherwise found from the pixels)
       - horizontal limits: the conversation column (hints, otherwise the sidebar edge is detected)
  3. segment that region into text lines, estimate the background colour (light/dark theme) and drop
     everything that is not reply text: the row of tiny action icons (copy / like / share ...),
     lone status chips, the footer disclaimer
  4. crop, convert to clean dark-on-light greyscale, upscale
  5. OCR with the first engine that works: rapidocr, the tesseract program, or any callable you pass in
  6. clean the text (UI words, header labels) and return it

No third-party package is required for steps 1-4.
"""
import io, os, re, shutil, struct, subprocess, sys, tempfile, zlib

try:                                    # optional speed-up
    from PIL import Image as _PIL
except Exception:                       # pragma: no cover
    _PIL = None


# ------------------------------------------------------------------ PNG in / out
class Shot:
    """Greyscale grid (G channel) of a screenshot: rows[y] is `bytes` of length w."""
    def __init__(self, w, h, rows):
        self.w, self.h, self.rows = w, h, rows


def _paeth(a, b, c):
    p = a + b - c
    pa, pb, pc = abs(p - a), abs(p - b), abs(p - c)
    return a if pa <= pb and pa <= pc else (b if pb <= pc else c)


def decode(data):
    if _PIL is not None:
        im = _PIL.open(io.BytesIO(data)).convert("RGB")
        w, h = im.size
        g = im.getchannel("G").tobytes()
        return Shot(w, h, [g[y * w:(y + 1) * w] for y in range(h)])
    if data[:8] != b"\x89PNG\r\n\x1a\n":
        raise ValueError("not a PNG")
    pos, idat, w = 8, [], 0
    while pos < len(data):
        n, kind = struct.unpack(">I4s", data[pos:pos + 8])
        body = data[pos + 8:pos + 8 + n]
        if kind == b"IHDR":
            w, h, depth, ctype, _, _, inter = struct.unpack(">IIBBBBB", body)
            if depth != 8 or inter or ctype not in (0, 2, 4, 6):
                raise ValueError("unsupported PNG type")
            ch = {0: 1, 2: 3, 4: 2, 6: 4}[ctype]
        elif kind == b"IDAT":
            idat.append(body)
        pos += 12 + n
    raw = zlib.decompress(b"".join(idat))
    stride, rows, prev, p = w * ch, [], bytearray(w * ch), 0
    gi = 1 if ch >= 3 else 0
    for _ in range(h):
        ft = raw[p]
        line = bytearray(raw[p + 1:p + 1 + stride])
        p += 1 + stride
        if ft == 1:
            for i in range(ch, stride):
                line[i] = (line[i] + line[i - ch]) & 255
        elif ft == 2:
            line = bytearray((a + b) & 255 for a, b in zip(line, prev))
        elif ft == 3:
            for i in range(stride):
                left = line[i - ch] if i >= ch else 0
                line[i] = (line[i] + ((left + prev[i]) >> 1)) & 255
        elif ft == 4:
            for i in range(stride):
                a = line[i - ch] if i >= ch else 0
                c = prev[i - ch] if i >= ch else 0
                line[i] = (line[i] + _paeth(a, prev[i], c)) & 255
        rows.append(bytes(line[gi::ch]))
        prev = line
    return Shot(w, h, rows)


def encode_gray(w, h, rows):
    raw = b"".join(b"\x00" + r for r in rows)

    def chunk(kind, body):
        c = struct.pack(">I", len(body)) + kind + body
        return c + struct.pack(">I", zlib.crc32(kind + body) & 0xFFFFFFFF)
    return (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 0, 0, 0, 0))
            + chunk(b"IDAT", zlib.compress(raw, 6)) + chunk(b"IEND", b""))


# ------------------------------------------------------------------ layout analysis
def _background(shot, x0, x1, y0, y1):
    hist = {}
    for y in range(y0, y1, 3):
        for v in shot.rows[y][x0:x1:4]:
            q = v >> 2
            hist[q] = hist.get(q, 0) + 1
    return (max(hist, key=hist.get) << 2) + 2 if hist else 255


def _sidebar_edge(shot, y0, y1):
    """x where the page background changes from the sidebar's to the main column's (0 if none)."""
    ys = range(y0, y1, max(1, (y1 - y0) // 14))
    prof = []
    for x in range(0, shot.w, 4):
        vals = sorted(shot.rows[y][x] for y in ys)
        prof.append(vals[len(vals) // 2])
    main = prof[len(prof) * 3 // 4]
    for i in range(1, len(prof) - 1):
        if abs(prof[i] - main) <= 3 and all(abs(p - main) <= 3 for p in prof[i:i + 12]) and abs(prof[0] - main) > 3 and i * 4 < shot.w // 2:
            return i * 4
    return 0


def _find_bands(shot, x0, x1, y0, y1, bg, thresh=48):
    """Text lines as (top, bottom, left, right, ink_pixels) found by horizontal projection."""
    rows = []
    for y in range(y0, y1):
        row = shot.rows[y]
        ink, left, right = 0, None, 0
        for x in range(x0, x1, 2):
            if abs(row[x] - bg) > thresh:
                ink += 1
                if left is None:
                    left = x
                right = x
        rows.append((ink, left, right))
    bands, start, gap = [], None, 0
    for i, (ink, _, _) in enumerate(rows):
        if ink:
            if start is None:
                start = i
            gap = 0
        elif start is not None:
            gap += 1
            if gap > 7:
                bands.append((start, i - gap))
                start, gap = None, 0
    if start is not None:
        bands.append((start, len(rows) - 1 - gap))
    out = []
    for a, b in bands:
        seg = rows[a:b + 1]
        ls = [r[1] for r in seg if r[1] is not None]
        rs = [r[2] for r in seg if r[1] is not None]
        out.append((y0 + a, y0 + b, min(ls), max(rs), sum(r[0] for r in seg)))
    return out


def _runs(shot, band, bg, thresh=48):
    """Ink blobs along a text band as (start, end) x-ranges; gaps of <=2px (letters) are merged."""
    top, bottom, left, right, _ = band
    runs, start, last = [], None, None
    for x in range(left, right + 1):
        if any(abs(shot.rows[y][x] - bg) > thresh for y in range(top, bottom + 1, 2)):
            if start is None:
                start = x
            elif x - last > 3:
                runs.append((start, last))
                start = x
            last = x
    if start is not None:
        runs.append((start, last))
    return runs


def _is_icon_row(shot, band, bg):
    """The copy / like / dislike / share / retry row under a reply: a handful of small, widely
    spaced blobs. Words have ~4-8px gaps; icon buttons are spaced 10px or more apart."""
    top, bottom, left, right, ink = band
    h, w = bottom - top + 1, right - left + 1
    if h > 38 or w > 320:
        return False
    runs = _runs(shot, band, bg)
    if len(runs) < 2 or len(runs) > 9:
        return False
    gaps = sorted(b[0] - a[1] for a, b in zip(runs, runs[1:]))
    widest = max(r[1] - r[0] + 1 for r in runs)
    return gaps[len(gaps) // 2] >= 10 and widest <= 2.2 * h


def find_reply_region(shot, hints=None):
    """Return (x0, y0, x1, y1, info) of the reply, or None."""
    hints = hints or {}
    H, W = shot.h, shot.w
    y_top = int(hints.get("replyTop") or 0)
    y_bot = int(hints.get("replyBottom") or int(H * 0.82))
    y_top, y_bot = max(0, y_top), min(H, y_bot)
    if y_bot - y_top < 14:
        return None
    x0 = int(hints.get("mainLeft") or _sidebar_edge(shot, y_top, y_bot) or 0)
    x1 = int(hints.get("mainRight") or W)
    x0, x1 = max(0, x0 + 6), min(W, x1 - 6)
    bg = _background(shot, x0, x1, y_top, y_bot)
    if not hints.get("replyTop"):                         # no geometry: skip header + the user's filled bubble
        y_top = max(y_top, 56)
        bands = _find_bands(shot, x0, x1, y_top, y_bot, bg, 8)
        for b in bands:                                    # a bubble is a wide, dense, filled block
            if (b[3] - b[2]) > 40 and b[4] / max(1, (b[1] - b[0] + 1) * ((b[3] - b[2]) // 2)) > 0.55:
                y_top = b[1] + 6
        bg = _background(shot, x0, x1, y_top, y_bot)
    bands = [b for b in _find_bands(shot, x0, x1, y_top, y_bot - 8, bg) if (b[1] - b[0] + 1) >= 6]   # drop borders / shadows
    if not bands:
        return None
    while bands and _is_icon_row(shot, bands[-1], bg) and len(bands) > 1:   # copy / like / share icons
        bands.pop()
    while bands and (bands[0][1] - bands[0][0]) < 9 and len(bands) > 1 and bands[0][3] - bands[0][2] < 120:
        bands.pop(0)                                              # tiny leading chip ("Thought for 4s")
    left = min(b[2] for b in bands)
    right = max(b[3] for b in bands)
    top, bottom = bands[0][0], bands[-1][1]
    info = {"bg": bg, "dark": bg < 128, "lines": len(bands)}
    return (max(0, left - 8), max(0, top - 6), min(W, right + 9), min(H, bottom + 7), info)


def crop_for_ocr(shot, box, dark, scale=2):
    x0, y0, x1, y1 = box
    inv = bytes(255 - i for i in range(256)) if dark else None
    out = []
    for y in range(y0, y1):
        r = shot.rows[y][x0:x1]
        if inv:
            r = r.translate(inv)
        if scale > 1:
            big = bytearray(len(r) * scale)
            for k in range(scale):
                big[k::scale] = r
            r = bytes(big)
        out.extend([r] * scale)
    return (x1 - x0) * scale, (y1 - y0) * scale, out


# ------------------------------------------------------------------ OCR
def _ocr_rapid(png):
    from rapidocr_onnxruntime import RapidOCR
    res, _ = RapidOCR()(png)
    if not res:
        return ""
    res.sort(key=lambda r: (round(r[0][0][1] / 12), r[0][0][0]))
    lines, cur, last = [], [], None
    for box, text, _ in res:
        yy = round(box[0][1] / 12)
        if last is not None and yy != last:
            lines.append(" ".join(cur)); cur = []
        cur.append(text); last = yy
    lines.append(" ".join(cur))
    return "\n".join(lines)


def _ocr_tesseract(png):
    exe = shutil.which("tesseract")
    if not exe:
        raise RuntimeError("tesseract not installed")
    with tempfile.TemporaryDirectory() as d:
        p = os.path.join(d, "r.png")
        open(p, "wb").write(png)
        r = subprocess.run([exe, p, "stdout", "--psm", "6", "-l", "eng"], capture_output=True, text=True, timeout=90)
        if r.returncode != 0:
            raise RuntimeError(r.stderr.strip()[:200])
        return r.stdout


def ocr(png, extra=None):
    """Try every OCR engine; returns (text, engine_name)."""
    errors = []
    engines = [("rapidocr", _ocr_rapid), ("tesseract", _ocr_tesseract)]
    if extra:
        engines.append(("browser-tesseract.js", extra))
    for name, fn in engines:
        try:
            text = fn(png)
            if text and text.strip():
                return text, name
        except Exception as exc:
            errors.append("%s: %s" % (name, str(exc).splitlines()[0][:120] if str(exc) else type(exc).__name__))
    raise RuntimeError("no OCR engine produced text (" + "; ".join(errors) + ")")


# ------------------------------------------------------------------ cleaning
UI_LINES = re.compile(
    r"^(chatgpt( said)?:?|you said:?|copy( code)?|edit( message)?|good response|bad response|share|retry|regenerate|"
    r"read aloud|more actions|try again|thinking\b.*|thought for .*|searching( the web)?\.*|stop( generating| streaming)?|"
    r"ask anything|message chatgpt|chatgpt can make mistakes.*|check important info.*|upgrade.*|get plus.*|"
    r"continue generating|sources?|show more|[0-9]+\s*/\s*[0-9]+|[<>«»‹›]+)$", re.I)


def is_symbol_only(line):
    """Emoji / icon-font glyphs (copy, like, share buttons) with no letters, digits or ASCII punctuation.
    ASCII punctuation is kept on purpose so JSON braces, brackets and quotes in a reply survive."""
    return not any(c.isalnum() or (c.isascii() and not c.isspace()) for c in line)


def clean(text, prompt=""):
    prompt_norm = " ".join(prompt.lower().split())
    out = []
    for raw in text.replace("\r", "").split("\n"):
        line = raw.strip()
        if not line or UI_LINES.match(line) or is_symbol_only(line):
            continue
        if len(line) > 12 and " ".join(line.lower().split()) in prompt_norm:   # echo of the user's own message
            continue
        out.append(line)
    return "\n".join(out).strip()


# ------------------------------------------------------------------ public entry
def analyze(png, hints=None, prompt="", extra_ocr=None):
    """png bytes -> {"text", "box", "engine", "info"}; raises RuntimeError when nothing usable is found."""
    shot = decode(png)
    region = find_reply_region(shot, hints)
    if not region:
        raise RuntimeError("no reply text found in the screenshot")
    x0, y0, x1, y1, info = region
    w, h, rows = crop_for_ocr(shot, (x0, y0, x1, y1), info["dark"], 2)
    crop_png = encode_gray(w, h, rows)
    text, engine = ocr(crop_png, extra_ocr)
    text = clean(text, prompt)
    if not text:
        raise RuntimeError("the screenshot contained no readable reply")
    return {"text": text, "box": (x0, y0, x1, y1), "engine": engine, "info": info, "crop_png": crop_png}


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("usage: python screen_reply.py screenshot.png [replyTop replyBottom mainLeft mainRight]")
        sys.exit(1)
    hint_keys = ("replyTop", "replyBottom", "mainLeft", "mainRight")
    hints = dict(zip(hint_keys, map(int, sys.argv[2:6])))
    res = analyze(open(sys.argv[1], "rb").read(), hints)
    print("engine:", res["engine"], "box:", res["box"], res["info"])
    print(res["text"])
