#!/usr/bin/env python3
"""Automatic library checker/installer. Run by start.sh and start.bat with the
project's virtualenv Python, so everything lands in .venv (never system Python).

  python deps.py                 check, install whatever is missing, then exit 0/1
  python deps.py --force         reinstall everything
  python deps.py --usb           (Termux) also make sure libusb + termux-api exist
Env: SKIP_DEPS_CHECK=1 (skip entirely), SKIP_BROWSER_DOWNLOAD=1 (no Chromium download),
     SKIP_CHROMIUM=1 (Termux: don't pkg-install chromium).
"""
import hashlib, importlib.util, os, shutil, subprocess, sys

HERE = os.path.dirname(os.path.abspath(__file__))
STAMP = os.path.join(sys.prefix, ".deps_stamp")
IS_WIN = sys.platform == "win32"
BROWSER = os.environ.get("CODA_BROWSER", "auto").strip().lower()      # auto | chrome | firefox (from start.sh)
IS_TERMUX = bool(os.environ.get("TERMUX_VERSION")) or "com.termux" in os.environ.get("PREFIX", "")

CORE = {"flask": "flask", "flask_cors": "flask-cors", "serial": "pyserial"}
WIN = {"pycaw": "pycaw", "comtypes": "comtypes"} if IS_WIN else {}
DESKTOP = {} if IS_TERMUX else {"playwright": "playwright"}   # pillow / rapidocr are optional extras


def say(msg):
    print("[deps] " + msg, flush=True)


def have(mod):
    try:
        return importlib.util.find_spec(mod) is not None
    except (ImportError, ValueError):
        return False


def missing(group):
    return [pkg for mod, pkg in group.items() if not have(mod)]


def digest():
    h = hashlib.sha256()
    h.update(("%d.%d|%s|%s" % (sys.version_info[0], sys.version_info[1], sys.platform, BROWSER)).encode())
    for name in ("requirements.txt", "requirements-desktop.txt"):
        p = os.path.join(HERE, name)
        if os.path.exists(p):
            h.update(open(p, "rb").read())
    return h.hexdigest()


def pip(*args):
    cmd = [sys.executable, "-m", "pip", "install", "--disable-pip-version-check"] + list(args)
    for attempt in (1, 2):
        if subprocess.call(cmd) == 0:
            return True
        if attempt == 1:
            say("pip failed; retrying once...")
    return False


def termux_pkg(*names):
    if not IS_TERMUX or not shutil.which("pkg"):
        return False
    return subprocess.call(["pkg", "install", "-y"] + list(names)) == 0


def main():
    argv = sys.argv[1:]
    if os.environ.get("SKIP_DEPS_CHECK") == "1":
        say("Skipped (SKIP_DEPS_CHECK=1).")
        return 0
    if sys.version_info < (3, 8):
        say("Python 3.8 or newer is required (found %d.%d)." % sys.version_info[:2])
        return 1
    if sys.prefix == getattr(sys, "base_prefix", sys.prefix):
        say("WARNING: not running inside the virtualenv; the launcher should have activated .venv.")

    force = "--force" in argv
    stamp_ok = (not force) and os.path.exists(STAMP) and open(STAMP).read().strip() == digest()
    gaps = missing(CORE) + missing(WIN) + missing(DESKTOP)

    if stamp_ok and not gaps:
        say("All libraries present (.venv).")
        if IS_TERMUX and "--usb" in argv:
            ensure_termux_usb()
        return 0

    if gaps:
        say("Missing: " + ", ".join(gaps))
    else:
        say("Requirements changed or first run; syncing libraries.")

    if not os.path.exists(os.path.join(sys.prefix, ".pip_upgraded")):
        pip("--upgrade", "pip", "setuptools", "wheel")
        open(os.path.join(sys.prefix, ".pip_upgraded"), "w").write("1")

    ok = pip("-r", os.path.join(HERE, "requirements.txt"))
    if DESKTOP:
        for line in open(os.path.join(HERE, "requirements-desktop.txt")):
            pkg = line.split("#")[0].strip()
            if pkg and not pip(pkg):
                say("Optional library '%s' could not be installed (non-fatal)." % pkg)

    core_gaps = missing(CORE) + missing(WIN)
    if core_gaps:
        say("Could not install: " + ", ".join(core_gaps))
        say("Check your internet connection and run the launcher again (or: python deps.py --force).")
        return 1

    if DESKTOP and have("playwright") and os.environ.get("SKIP_BROWSER_DOWNLOAD") != "1":
        has_chrome = any(shutil.which(n) for n in ("google-chrome", "google-chrome-stable", "chrome")) or \
            any(os.path.exists(p) for p in (r"C:\Program Files\Google\Chrome\Application\chrome.exe",
                                            r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
                                            "/Applications/Google Chrome.app"))
        want = []
        if BROWSER in ("chrome", "auto") and not has_chrome:
            want.append("chromium")
        if BROWSER in ("firefox", "auto"):
            want.append("firefox")          # the AI browser's Firefox engine (ChatGPT uses your installed Firefox)
        if want:
            say("Downloading Playwright browser(s): %s (one time)..." % ", ".join(want))
            if subprocess.call([sys.executable, "-m", "playwright", "install"] + want) != 0:
                say("Browser download failed (non-fatal). Install Chrome/Firefox yourself or retry later.")

    if IS_TERMUX:
        if os.environ.get("SKIP_CHROMIUM") != "1":
            want_ff = BROWSER == "firefox"
            have_it = shutil.which("firefox") if want_ff else (shutil.which("chromium") or shutil.which("chromium-browser"))
            if not have_it:
                say("Installing %s for the ChatGPT website provider (one time)..." % ("Firefox" if want_ff else "Chromium"))
                termux_pkg("x11-repo")
                if not termux_pkg("firefox" if want_ff else "chromium"):
                    say("Install failed (non-fatal). Run: pkg install x11-repo %s" % ("firefox" if want_ff else "chromium"))
        if not shutil.which("tesseract"):
            say("Installing tesseract (OCR for the ChatGPT screenshot reader)...")
            if not termux_pkg("tesseract"):
                say("tesseract install failed (non-fatal; the in-browser OCR fallback is used instead).")
        if "--usb" in argv:
            ensure_termux_usb()

    with open(STAMP, "w") as f:
        f.write(digest())
    say("Libraries ready.")
    return 0


def ensure_termux_usb():
    import glob
    need = []
    if not glob.glob(os.path.join(os.environ.get("PREFIX", "/usr"), "lib", "libusb-1.0*")):
        need.append("libusb")
    if not shutil.which("termux-usb"):
        need.append("termux-api")
    if need:
        say("Installing Termux packages: " + ", ".join(need))
        termux_pkg(*need)
        if not shutil.which("termux-usb"):
            say("Also install the Termux:API app (F-Droid) so Android can grant USB access.")


if __name__ == "__main__":
    sys.exit(main())
