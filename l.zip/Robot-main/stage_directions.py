"""
stage_directions.py — the robot's body language.

The model may begin any spoken reply with ONE stage block:

    <stage>{"mood":"happy","hands":[{"side":"right","gesture":"wave","x":78,"y":56,"size":1,"count":3}]}</stage>

  * split_stage(text)  -> (clean_text, stage_or_None)
        removes every stage block (and an unterminated one at the end) so the
        words that are shown and spoken never contain the tag.
  * sanitize_stage(obj) -> a clean dict with clamped numbers and known names only.
  * STAGE_GUIDE        -> the instructions appended to the model's system prompt.

Everything here is pure Python with no dependencies, so it is safe on Termux.
"""
import json
import math
import re

MOODS = (
    "calm", "happy", "excited", "love", "proud", "curious", "thinking", "confused",
    "surprised", "scared", "sad", "annoyed", "sleepy", "tired", "wink", "laugh",
)
# Older names the kiosk used, so an old prompt still lands on a real expression.
MOOD_ALIASES = {"angry": "annoyed", "exhausted": "tired", "focused": "thinking"}
GESTURES = ("wave", "swipe", "point", "thumbs_up", "peace", "rest")
SPEEDS = ("slow", "normal", "fast")

_STAGE_RE = re.compile(r"<stage>(.*?)</stage>", re.S | re.I)
_STAGE_OPEN_RE = re.compile(r"<stage>.*\Z", re.S | re.I)

STAGE_GUIDE = """
STAGE DIRECTIONS (your face and hands on the kiosk screen):
Start a reply with one stage block, then the words you say. Example:
<stage>{"mood":"happy","hands":[{"side":"right","gesture":"wave","x":78,"y":56,"size":1,"count":3}]}</stage>
The block is valid JSON, is never spoken, and is never mentioned. Leave it out when nothing needs showing.
- mood (optional): one of calm, happy, excited, love, proud, curious, thinking, confused, surprised, scared, sad, annoyed, sleepy, tired, wink, laugh. Pick the feeling your words carry. Keep it mostly calm; a mood fades back to calm by itself.
- hands (optional, at most two): a hand slides in from the side you choose, performs one gesture, then slides out. Use hands sparingly, for goodbyes, showing or pointing at something, celebrating, or a demo. Do not use them on most replies. Each hand takes these fields:
  side: "left" or "right" (the screen edge it comes from)
  gesture: wave, swipe, point, thumbs_up, peace or rest
  x, y: where it sits, as percent of the screen (x 0 = left edge, 100 = right; y 0 = top, 100 = bottom). Keep x between 12 and 88 and y between 15 and 85.
  size: 0.5 to 2 (1 is normal)
  count: number of waves or swipes, 1 to 5
  speed: slow, normal or fast
  swipe_to: for swipe, the x percent where the swipe ends
  hold: seconds to stay out, 0.5 to 10
- Be expressive but never cringe: no fake excitement, no emoji in the words, no performing feelings you do not have.
""".strip()


def _num(value, default, lo, hi):
    try:
        number = float(value)
    except (TypeError, ValueError):
        return default
    if not math.isfinite(number):
        return default
    return max(lo, min(hi, number))


def sanitize_stage(obj):
    """Keep only known keys and clamp every number. Returns None when nothing usable is left."""
    if not isinstance(obj, dict):
        return None
    out = {}
    mood = str(obj.get("mood", "")).strip().lower()
    mood = MOOD_ALIASES.get(mood, mood)
    if mood in MOODS:
        out["mood"] = mood
    hands = []
    raw_hands = obj.get("hands")
    if isinstance(raw_hands, dict):
        raw_hands = [raw_hands]
    for hand in (raw_hands if isinstance(raw_hands, list) else [])[:2]:
        if not isinstance(hand, dict):
            continue
        side = "left" if str(hand.get("side", "right")).strip().lower().startswith("l") else "right"
        gesture = str(hand.get("gesture", "wave")).strip().lower().replace("-", "_")
        if gesture not in GESTURES:
            gesture = "wave"
        speed = str(hand.get("speed", "normal")).strip().lower()
        if speed not in SPEEDS:
            speed = "normal"
        item = {
            "side": side,
            "gesture": gesture,
            "x": round(_num(hand.get("x"), 16 if side == "left" else 84, -10, 110), 1),
            "y": round(_num(hand.get("y"), 56, 5, 95), 1),
            "size": round(_num(hand.get("size"), 1.0, 0.5, 2.0), 2),
            "count": int(_num(hand.get("count"), 2, 1, 5)),
            "speed": speed,
            "hold": round(_num(hand.get("hold"), 2.5, 0.5, 10), 2),
        }
        if "swipe_to" in hand:
            item["swipe_to"] = round(_num(hand.get("swipe_to"), item["x"], -10, 110), 1)
        hands.append(item)
    if hands:
        out["hands"] = hands
    return out or None


def split_stage(text):
    """Return (words_without_tags, stage_dict_or_None). Never raises."""
    text = "" if text is None else str(text)
    stage = None
    match = _STAGE_RE.search(text)
    if match:
        try:
            stage = sanitize_stage(json.loads(match.group(1).strip()))
        except (ValueError, TypeError):
            stage = None
    clean = _STAGE_RE.sub("", text)
    clean = _STAGE_OPEN_RE.sub("", clean)          # a block cut off by the token limit
    clean = re.sub(r"\n{3,}", "\n\n", clean).strip()
    return clean, stage
