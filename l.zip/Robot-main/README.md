# CODA — AI Soda Dispenser

A talking robot kiosk that invents soda recipes with AI and pours them with up to nine pumps.
An Arduino Uno drives the pumps; a small Python (Flask) backend runs the logic and serves the
kiosk web page. The kiosk has an animated face, voice input and output, a music player, a
workspace for graphs and simulations, and an AI-operated web browser.

It runs on a **laptop** (Windows / macOS / Linux) or on an **Android TV / phone through Termux**,
with a real Arduino, or fully **simulated** with no hardware at all.

## Contents

1. [Quick start](#1-quick-start)
2. [How it fits together](#2-how-it-fits-together)
3. [Installing, launching and portable use](#3-installing-and-launching)
4. [Hardware: Arduino, pumps, safety, flow sensors](#4-hardware)
5. [Using the kiosk](#5-using-the-kiosk)
6. [AI setup: Groq, OmniRoute, ChatGPT website, ElevenLabs](#6-ai-setup)
7. [Faces, subtitles, listening and sounds](#7-faces-subtitles-listening-and-sounds)
8. [Workspace, music and agent browser](#8-workspace-music-and-agent-browser)
9. [LCD display](#9-lcd-display)
10. [Reference: environment variables, HTTP routes, files](#10-reference)
11. [Troubleshooting](#11-troubleshooting)

---

## 1. Quick start

| I want to... | Run | Where |
|---|---|---|
| Try it with no hardware | `bash start.sh mock` / `start.bat mock` (plain `bash start.sh` is also simulated on Termux) | anywhere |
| Use a real Arduino from a laptop | `start.bat` (Windows) or `bash start.sh serial` | laptop |
| Use a real Arduino from the TV | `bash start.sh termux` | Termux |
| See which USB devices the TV can see | `bash start.sh probe` | Termux |
| Install every library without starting | `bash start.sh setup` / `start.bat setup` | anywhere |
| See every command, option and variable | `bash start.sh help` / `start.bat help` | anywhere |

The first run creates a private Python virtualenv (`.venv-<os>`) and installs everything by itself.
Then open **http://localhost:5005/**.

The badge at the top-left of the kiosk always says what you are talking to:
**SIMULATED**, **ARDUINO CONNECTED (termux/serial)**, or **ARDUINO NOT FOUND — reason**.

---

## 2. How it fits together

```
 Browser (kiosk.html)  <--HTTP-->  backend.py (Flask, port 5005)  <--USB serial-->  Arduino Uno -> pumps
   face, voice, UI                   |- pump logic, safety, recipes
   music / workspace / browser dock  |- AI providers (Groq / OmniRoute / ChatGPT website)
                                     |- ElevenLabs voice streaming
                                     |- agent.py          tool-using agent (/agent/chat)
                                     |- agent_browser.py  browser for the AI (/browse/...)
                                     |- display.py        16x2 LCD controller
                                     '- chatgpt_web.py    drives the ChatGPT website
```

The Arduino link is pluggable: `mock` (simulated), `serial` (pyserial, laptops) or `termux`
(raw USB through `usb_transport.py`, Android).

---

## 3. Installing and launching

### 3.1 What the launchers do for you

`start.sh` and `start.bat` create a virtualenv in **`.venv-<os>`** (e.g. `.venv-linux`), activate it, and run **`deps.py`**,
which checks every library and installs whatever is missing:

- Everywhere: Flask, Flask-CORS, pySerial
- Windows: pycaw, comtypes (real device volume)
- Laptops/PCs: Playwright and its Chromium (downloaded once, skipped if Google Chrome is installed)
- Termux: Chromium for the ChatGPT website mode, and for `termux` mode libusb + termux-api

Re-runs take well under a second. Editing `requirements*.txt` triggers an automatic resync. A broken
virtualenv (Python moved or upgraded) is recreated automatically; delete `.venv-<os>` any time for a fresh start.

| Command | Effect |
|---|---|
| `bash start.sh setup` / `start.bat setup` | Install everything, then exit |
| `bash start.sh --reinstall [mode]` / `start.bat --reinstall [mode]` | Force a clean reinstall, then start |
| `SKIP_DEPS_CHECK=1` | Skip the library check |
| `SKIP_BROWSER_DOWNLOAD=1` | Don't download Playwright's Chromium (laptops) |
| `SKIP_CHROMIUM=1` | Don't install Chromium (Termux) |

**Browser question.** Interactive runs ask which browser ChatGPT and the AI browser should use:
`1) System default`, `2) Google Chrome / Chromium / Edge`, `3) Mozilla Firefox` (Enter keeps your last
choice, which is saved in `.coda_browser` and passed on as `CODA_BROWSER`). Skip the question with
`--browser default|chrome|firefox` or `--no-ask`; force it again with `--ask`. `bash start.sh help` lists every
mode, option and environment variable (`start.bat help` on Windows).

Python 3.8 or newer is required. On Debian/Ubuntu, if venv creation fails: `sudo apt install python3-venv`.
`start.bat` offers to install Python with `winget` if it is missing.

### 3.2 Portable use (USB stick)

The whole project folder is portable; run it straight from the drive:

| What | Where it lives | Travels with the drive? |
|---|---|---|
| API keys, voice ID, provider choices | `data/ai_settings.json` | yes |
| Kiosk settings (face, keyword, sounds, music, interface, personality, pump setup) | `data/browser_storage.json` | yes |
| ChatGPT browser login/profile | `data/chatgpt_profile/` | the folder yes, but see below |
| Libraries | `.venv-win`, `.venv-linux`, `.venv-mac`, `.venv-termux` (one per OS, built on first run there) | per OS |
| Logs, browser choice, LCD config, downloads | `logs/`, `.coda_browser`, `display_config.json`, `downloads/` | yes |

Notes: **Python must be installed on each computer** (it is not carried). The first run on a new PC builds that OS's
virtualenv, which takes a minute and needs internet; later runs are instant. Use `bash start.sh` (not `./start.sh`) on
FAT/exFAT sticks, which can't mark files executable. Virtualenvs are created with real copies, not symlinks, so exFAT
works. A ChatGPT login stored by the browser may not carry between PCs (Windows ties cookies to the user account), so
you may have to sign in again. If the drive is read-only the backend falls back to saving on that PC and logs a warning.
Settings are mirrored from the kiosk page to the drive within a second of each change.

### 3.3 Laptop (Windows / macOS / Linux)

1. Install Python 3 (Windows: tick "Add python.exe to PATH").
2. Plug in the Uno and run `start.bat` (Windows) or `bash start.sh` (macOS/Linux). The Arduino's port is
   found automatically. Force one with `set PUMP_SERIAL_PORT=COM5` (Windows) or
   `export PUMP_SERIAL_PORT=/dev/ttyACM0`.
3. No Arduino? Use `start.bat mock` or `bash start.sh mock`.
4. Cheap Uno clones on Windows may need the **CH340 driver**.
5. To open the kiosk on another device (e.g. the TV) while the laptop runs the backend, start with
   `PUMP_HOST=0.0.0.0` and browse to `http://<laptop-ip>:5005/`.

### 3.4 Android TV / phone (Termux)

One-shot installer, from the project folder:

```bash
bash termux_setup.sh              # core (simulated Arduino)
bash termux_setup.sh --chatgpt    # + Chromium for the ChatGPT website provider
bash termux_setup.sh --usb        # + real Arduino over USB
bash termux_setup.sh --all        # everything
```

It installs the Termux packages, runs `bash start.sh setup`, and creates a **`coda`** command
(keeps the device awake, then runs `start.sh`). Afterwards:

```bash
coda            # simulated Arduino
coda termux     # real Arduino over USB
```

For a real Arduino also install the **Termux:API** app (same source as Termux, e.g. F-Droid). Every time:

1. Close ArduinoDroid (only one app can hold the Uno).
2. Plug in the Uno and run `coda termux`.
3. When Android shows the **USB permission popup, tap OK**.
4. Check the badge says ARDUINO CONNECTED (termux).

Open the kiosk as **http://localhost:5005** so the microphone and keyword listening work.

---

## 4. Hardware

### 4.1 The Arduino sketch

Upload one sketch with the Arduino IDE (board: Arduino Uno):

| Sketch | Use for |
|---|---|
| `pump_controller_uno_lcd.ino` | **Recommended.** Uno with the 16x2 I2C LCD, emergency-stop input, heartbeat and buzzer. Put it in a folder named `pump_controller_uno_lcd` so the IDE opens it. |
| `pump_controller_uno.ino` | Uno without the LCD and without the stop/buzzer features |
| `pump_controller.ino` | Arduino Mega |
| `flow_sensor_uno.ino` | Optional second Uno that counts flow-sensor pulses |

Check it from the Serial Monitor at **9600 baud**: send `PING` and expect `PONG ESTOP=0`; send
`FIRE 1 500 80` and expect `OK`, then `DONE 1`.

Serial commands (newline-terminated): `FIRE <pump 1-9> <ms> <speed%>`, `START <pump> <speed%>`,
`STOP <pump>`, `STOPALL`.

### 4.2 Pins and wiring (Uno)

- Pumps 1-6 on pins **3, 5, 6, 9, 10, 11** (PWM, speed control works).
- Pumps 7-9 on pins **2, 4, 7** (on/off only).
- Pumps 1-8 are flavor pumps; **pump 9 is the primary sparkling-water pump**.
- Pumps go through **MOSFET drivers with their own power supply** — never straight to an Arduino pin.
- LCD backpack: GND, 5V, SDA to A4, SCL to A5. If you only see solid blocks, turn the blue contrast trimmer.

### 4.3 Emergency stop and buzzer

- **D8** reads the emergency-stop switch's isolated normally-closed auxiliary contact (wire it between D8 and
  GND, `INPUT_PULLUP`). An open contact (pressed switch or broken wire) trips and latches the stop.
- The switch's other normally-closed pole must **interrupt the pump-driver supply directly**; D8 is only the
  reporting/lockout input. The switch and power-cut device must be rated for the pump supply and current.
- Reset only after releasing the switch and checking the hardware (kiosk: **Reset emergency stop**).
- **D12** drives an active buzzer. Do not connect a high-current buzzer directly: use a transistor/MOSFET
  driver with a shared ground and any suppression the datasheet requires.
- Buzzer patterns: two short beeps when the backend first connects; one short beep when the flow-sensor Uno is
  found; one long beep on a controller/backend or sensor-board disconnect; three fast beeps then one long beep
  on emergency stop. If no backend connects within five seconds of boot the LCD shows `BACKEND OFFLINE` and the
  buzzer sounds once.

### 4.4 Flow sensors (optional)

Upload `flow_sensor_uno.ino` to a second Uno on its own USB cable. Connect up to nine digital pulse-output flow
sensors to D2-D10 with a shared ground; keep D0/D1 free for USB serial. Use sensors certified food-safe for your
drinks, tubing and pressure. Pulse counts indicate liquid movement, not exact volume — calibrate each sensor. The
System diagnostics flag a running pump with no recent pulses after a short grace period.

The pump Uno uses **9600** baud, the flow-sensor Uno **115200**; the backend uses the matching rate for each.
On Windows assign the two ports explicitly in the same PowerShell window before launching:

```powershell
$env:PUMP_SERIAL_PORT = 'COM4'
$env:FLOW_SENSOR_PORT = 'COM5'
.\start.bat serial
```

Use the ports shown in Device Manager; they must differ. Leave `FLOW_SENSOR_PORT` unset if you have no sensor board.

### 4.5 Termux USB details

On Android an Arduino is not a serial port; `usb_transport.py` speaks the serial protocol over a raw USB file
descriptor handed out by `termux-usb`. Supported chips: **CDC-ACM** (genuine Uno/Mega/Leonardo, VID 2341) and
**CH340** (cheap clones, VID 1A86, best-effort). FTDI and CP210x are detected and reported but not driven.
`bash start.sh probe` prints the VID:PID and USB layout of what is plugged in.

---

## 5. Using the kiosk

Open **http://localhost:5005/**. Type or say what you want ("a berry soda with less sweetness"); the robot
proposes a recipe and **nothing is poured until you confirm it**. When a drink is ordered the face shrinks to the
top-left and a dock (Workspace / Music / Browser) opens beside the recipe card. The **TOOLS** button opens the dock
any time. `Ctrl` + `+` toggles full screen. Use Chrome or Edge for voice features.

**Recipe limits:** at most three ingredients, 12 seconds per pump, 24 total pump-seconds. Exact volume needs
calibrated pump flow and ingredient density data, which are not configured by default.

### Settings (gear icon)

| Tab | What it does |
|---|---|
| **System** | Choose chat and recipe providers, API keys, ChatGPT browser, diagnostics, full screen |
| **Pumps & flavors** | Name each pump, set seconds and speed, run or stop pumps; **Stop all** |
| **Personality** | Edit Coda's system prompt and the AI memory |
| **Command history** | Past drink commands |
| **Face** | Pick face v1 or v2 and customise each (section 7) |
| **Listening** | Always-on keyword listening (section 7) |
| **Sounds** | Sound effects (section 7) |
| **Self-test** | Runs every ticked pump one after another at its saved speed to check wiring and flow |

### Other pages

| URL | Page |
|---|---|
| `/` | The kiosk |
| `/test` | Pump test dashboard (manual pump control, simulated/real status pill) |
| `/display` | LCD display settings |
| `/aura` | The AURA workspace console on its own |

---

## 6. AI setup

Chat and drink recipes can use **different providers and models**. Provider changes apply immediately and reload
only that provider's model list.

| Provider | Needs | Notes |
|---|---|---|
| **Groq** | API key from the [Groq console](https://console.groq.com/keys) | Default: `openai/gpt-oss-120b` for recipes, `openai/gpt-oss-20b` for chat. Quotas vary by account. |
| **OmniRoute** | OmniRoute running locally at `http://localhost:20128` | OpenAI-compatible API at `/v1`; use the combo/model IDs from its dashboard. |
| **ChatGPT website** | A browser signed in to ChatGPT (6.2) | Best-effort, no API key. |
| **ElevenLabs** (voice) | API key from [ElevenLabs](https://elevenlabs.io/app/settings/api-keys) | Model `eleven_flash_v2_5`; streams audio plus character timings so captions follow the voice. The voice ID is changeable in Settings. The free tier lists 10,000 credits/month, charged per character. |

Enter keys in **Settings > System** and press **Save providers**. Keys go to the backend (never into the page) and are
**saved permanently** in `data/ai_settings.json` next to the scripts, so they survive restarts and travel with the
folder (see section 3.2). The file is **plain text**: keep the drive private, delete `data/` to forget everything, or
start with `CODA_SAVE_KEYS=0` to keep keys in memory only. A real `GROQ_API_KEY` / `ELEVENLABS_API_KEY` environment
variable still takes priority over the saved file. Settings from older versions (stored in `%LOCALAPPDATA%\PumpKiosk`
or `~/.config/PumpKiosk`) are imported automatically on the first run.

If a proxy blocks Groq, set `GROQ_PROXY=direct` before starting (Windows: `set GROQ_PROXY=direct`), or
`GROQ_PROXY=http://host:port` for a specific proxy.

### 6.1 Voice input and output

**TALK** uses the browser's speech recognition (needs browser support and microphone permission). Replies are
spoken with ElevenLabs, with subtitles following its timing data.

### 6.2 ChatGPT website mode

In **Settings > System** press **Open ChatGPT browser**. The backend opens a separate, persistent browser profile
on the machine running the backend; sign in (or use guest access if ChatGPT offers it), complete any checks, then
choose **ChatGPT website** for chat and/or recipes and press **Save providers**. No password, cookie or profile is
copied into the kiosk page.

How it works: every request opens a **fresh chat**, types the prompt with Shift+Enter line breaks (so it never
submits early), sends it, and reads the reply as it streams. A drink order makes one ChatGPT call.

**Reading the reply (three layers, so a ChatGPT redesign can't silently break it):**

1. the page's own assistant-message elements;
2. a structure-free **text diff**: everything on the page that is new since before the prompt was sent, minus your
   prompt and ChatGPT's UI words and icon glyphs;
3. a **screenshot analyzer** (`screen_reply.py`) used when layers 1-2 find nothing: it finds the reply region in a
   picture of the page (below your message bubble, above the composer, inside the conversation column, ignoring the
   copy/like/share icon row, sidebar and footer), crops **only** that, and OCRs it (rapidocr, then the `tesseract`
   program, then in-browser tesseract.js). If the page has no readable text at all it also decides "finished" by
   watching the pixels stop changing.

`CHATGPT_CAPTURE=auto|dom|screenshot` picks the strategy, `CHATGPT_TIMEOUT` (default 75 s) is the stuck-request
ceiling, and `CHATGPT_DEBUG_DIR=/some/folder` saves the screenshot and crop it analysed. OCR text is never as exact
as page text (JSON quotes and code can be misread), so the screenshot layer is a fallback, not the first choice.

This is a best-effort integration of the visible page, **not an official API**. It was tested against mock ChatGPT
pages (normal markup, no markup hooks, and a canvas with no text), not the live site.

**Browsers:** Chrome/Chromium/Edge (Playwright, or the built-in DevTools driver on Termux) and **Firefox** (a built-in
Marionette driver using your installed Firefox; the AI browser's full engine uses Playwright's Firefox). The Firefox
paths have been checked against a protocol simulator only, not a real Firefox.

| Where | How it runs |
|---|---|
| **Laptop** | Playwright with Google Chrome (or its bundled Chromium). Installed automatically by the launcher. |
| **Termux, standalone** | `bash termux_setup.sh --chatgpt`. Termux's Chromium runs **headless** with a built-in DevTools driver — no Playwright, no X server, no laptop. Press *Open ChatGPT browser*; a **live sign-in view** appears in the panel (tap to click, **Keyboard** to type). The login is kept in the profile folder. If ChatGPT shows a bot check a headless browser cannot pass, use the bridge. |
| **Remote bridge** | On a laptop run `python chatgpt_web.py --serve`; on the TV set `CHATGPT_BRIDGE_URL=http://<laptop-ip>:5006` (optionally `CHATGPT_BRIDGE_TOKEN`) before `bash start.sh`. |

---

## 7. Faces, subtitles, listening and sounds

### 7.1 Two faces

**Settings > Face** switches between:

- **Version 1** — the procedural Cozmo-style canvas face (default).
- **Version 2** — the Koko eyes (glowing SVG eyes, mood shapes, gentle roaming), ported to plain JavaScript so no
  Node build is needed.

Each face keeps its **own saved settings**; the *Customising* selector chooses which one you edit, and
*Reset this face* restores its defaults.

| Group | Options |
|---|---|
| Look | Show mouth, face size, eye colour (follow mood / custom; v2 also Koko cyan), glow, idle floating (v2) |
| Emotions | Automatic expressions and seconds between them, react to what is said, pulse while speaking |
| Movement | Roam when idle, seconds between moves, roaming distance |
| Eyes | Blinking and gaze shifts, blink rate, how often it looks around, how far it looks, follow mouse/touch/focus, follow strength |
| Sleep | Fall asleep after N seconds (0 = never), floating Z's |

The face reacts to listening, thinking, speaking and sleeping, and docks top-left during a drink order. Face v2
has a Preview-a-mood row (calm, happy, curious, sleepy, shocked, frown, sad, annoyed, scared).

### 7.1b Expressions, virtual hands and stage directions

Both faces now share one eye model. Each eye is a rounded shape whose upper and lower lids can tilt or arch, so
every expression is a set of eased targets (no snapping, no rebuilt elements). Moods: calm, happy, excited, love,
proud, curious, thinking, confused, surprised, scared, sad, annoyed, sleepy, tired, laugh, wink. The robot also has
small moments of its own in idle (curious glances, the odd wink, a double blink). Sad, angry and scared are never
chosen at random. Sleep closes the lids to a thin line with a slow breath; waking reopens them.

**Virtual hands.** Glowing hands that slide in from a screen edge, perform one gesture (wave, swipe, point,
thumbs-up, peace, rest) and slide out. The reply can ask for them: each reply may begin with a stage block, which
is never shown or spoken:

    <stage>{"mood":"happy","hands":[{"side":"right","gesture":"wave","x":78,"y":56,"size":1,"count":3}]}</stage>

`stage_directions.py` holds the format, the validation (values are clamped, unknown names dropped) and the
instructions the model receives. The kiosk waves on its own when you say hello or goodbye. Settings > Face has a
Virtual hands section to switch hands off or change their size.

### 7.2 Subtitles and lyrics

- **Robot voice subtitles** behave as originally designed (unchanged).
- **Song lyrics** (music player) show one verse per line. A verse wider than the box is no longer cut with "..."; it
  **slides left as the words are sung**, keeping the current word in view (short verses don't move).

### 7.3 Always-on listening with a keyword

**Settings > Listening** > *Always listen for the keyword*. Say the keyword (default **`coda`**) and then your
request: "coda, make me a berry soda". It chimes, shows what it hears and sends the request after you pause.

- **Keyword** plus **Also accept**: a comma-separated list of extra trigger words or phrases and likely
  mishearings (e.g. `hey coda, okay robot`). Phrases must be heard next to each other. Single words of four or
  more letters tolerate one wrong letter.
- Also adjustable: how long it waits for a request after the keyword, the pause that ends a request, and the
  language.
- Listening pauses while the robot thinks or speaks so it does not hear itself.
- A status pill at the top-left shows listening, paused or blocked.
- Needs Chrome/Edge on `localhost` or HTTPS and microphone permission; recognition uses the browser's speech
  service.

### 7.4 Sound effects

**Settings > Sounds**: short synthesised sounds for keyword heard, listening, request sent, thinking, robot
speaking, recipe ready, pour start and finish, errors, sleep and wake, listening timeout, emergency stop and
setting toggles. Master volume, three styles (soft, synth, retro), a per-event switch and a Test button each. They
are separate from the music player, which is never touched.

---

## 8. Workspace, music and agent browser

Everything the robot says goes through a tool-using agent (`/agent/chat`), so voice or typed requests like these
just work:

- "Play Shape of You" — searches YouTube and plays it in the Music tab. "Raise the volume", "set it to 30",
  "mute". Music ducks while the robot talks or listens.
- "Graph sin x and x squared", "simulate a ball bouncing in 3D", "draw a circuit...", "coach me through this
  equation", "make a table of..." — rendered in the Workspace tab by the AURA engine (`aura.html`, also at `/aura`).
- "Look up ...", "open example.com", "download <url>" — the agent browser.
- "Move the player to the left", "hide the player", "skip the sponsors", "next song", "repeat".

### 8.1 Music player

`player.js` / `player.css`. Layouts: sidebar left/right, top bar, bottom bar, floating card, mini pill, hidden;
panels reserve space so the face's text and buttons are never covered. Spinning vinyl / CD / cover ring / square
cover with a tonearm. **SponsorBlock** segments (sponsors, self-promo, reminders, intros, outros, recaps,
non-music parts, filler) are skipped automatically or on request, with an Undo chip and marks on the progress bar,
plus your own "skip first/last N seconds". Search ranks "Topic"/official-audio uploads above music videos.
**Lyrics**: a single-line display where words go bold as they are sung and the line swipes up to the next (a verse wider than the box slides left as it is sung instead of being cut with "..."); synced
lyrics come from lrclib.net, falling back to YouTube captions, with estimated word timing when the source has none.

### 8.2 Interface customisation

`ui.js` / `ui.css`: icon set, motion system and the **Customize drawer** (sliders icon, top right and in the
player): accent, roundness, blur, text size, animation level and speed, and the player's elements. Saved in the
browser.

### 8.3 Agent browser

| | lite (default, runs on the TV/Termux) | full (laptop/PC) |
|---|---|---|
| Search, read pages, download files | yes | yes |
| Live view, click, type, scroll, tabs | no | yes (real Chromium) |

The full engine is picked automatically when Playwright is installed (the launcher installs it on laptops). To use a
laptop's browser from the TV: on the laptop run `BROWSER_HOST=0.0.0.0 BROWSER_TOKEN=secret python agent_browser.py`;
on the TV set `BROWSER_REMOTE=http://<laptop-ip>:5006 BROWSER_TOKEN=secret` before starting. Downloads then land on
the laptop. The browser refuses private/LAN addresses unless `BROWSER_ALLOW_PRIVATE=1`.

### 8.4 Volume

The YouTube player volume always works. Real device volume is used where available: Termux (`termux-api`), Linux
(`pactl`/`amixer`), macOS, Windows (pycaw, installed automatically).

### 8.5 Kiosk tips

Start Chrome with `--autoplay-policy=no-user-gesture-required` so music can start without a touch (otherwise a
"Tap to start" button appears). The dock needs internet for YouTube and for AURA's CDN libraries (Chart.js, KaTeX,
Pyodide).

---

## 9. LCD display

16x2 I2C LCD with a cat animation and live stats (layout 1:3 — 4 columns cat, 12 columns stats).

1. Upload `pump_controller_uno_lcd.ino` (no extra library needed).
2. Wire the backpack (section 4.2).
3. Start the backend and open **http://localhost:5005/display** to configure cat mood rules, tanks, stats pages,
   backlight and bar style. Settings are saved in `display_config.json`.
4. Tank levels drop by pump run time x speed x flow (ml/s), so enter each pump's real flow.

---

## 10. Reference

### 10.1 Environment variables

| Variable | Default | Purpose |
|---|---|---|
| `PUMP_TRANSPORT` | `mock` | `mock`, `serial`, `termux` (the launcher sets it from its first argument) |
| `PUMP_HOST` / `PUMP_PORT` | `127.0.0.1` / `5005` | Where the backend listens |
| `PUMP_SERIAL_PORT` | `auto` | Force the pump Uno's port |
| `FLOW_SENSOR_PORT` | unset | Flow-sensor Uno's port |
| `PUMP_USB_DEVICE` | auto | Termux: force a USB device path |
| `GROQ_API_KEY`, `GROQ_BASE_URL`, `GROQ_CHAT_MODEL`, `GROQ_RECIPE_MODEL`, `GROQ_PROXY` | see section 6 | Groq |
| `OMNIROUTE_BASE_URL` | `http://localhost:20128/v1` | OmniRoute |
| `ELEVENLABS_API_KEY`, `ELEVENLABS_VOICE_ID`, `ELEVENLABS_TTS_MODEL` | model `eleven_flash_v2_5` | ElevenLabs |
| `CODA_DATA_DIR` | `./data` | Where keys, settings and the ChatGPT profile are saved |
| `CODA_SAVE_KEYS` | `1` | `0` = never write API keys to disk |
| `CODA_BROWSER` | asked at start | `default`, `chrome` or `firefox` (set by start.sh / start.bat) |
| `CHATGPT_URL` | `https://chatgpt.com/` | Site the ChatGPT bridge opens |
| `CHATGPT_CAPTURE` | `auto` | `dom`, `screenshot` or both (section 6.2) |
| `CHATGPT_TIMEOUT` | `75` | Seconds before a stuck reply is abandoned |
| `CHATGPT_DEBUG_DIR` | unset | Save the analysed screenshot, hints and crop |
| `CHATGPT_MARIONETTE_PORT` | `2829` | Firefox remote-control port |
| `CHATGPT_DRIVER` | `auto` | `playwright` or `cdp` |
| `CHATGPT_HEADLESS` | auto | `1` forces headless (automatic when there is no display) |
| `CHATGPT_BROWSER` | auto | Path to a Chrome/Chromium binary |
| `CHATGPT_CDP_URL` | unset | Attach to a browser already started with remote debugging |
| `CHATGPT_CDP_PORT` | `9223` | DevTools port for the browser it starts |
| `CHATGPT_BRIDGE_URL`, `CHATGPT_BRIDGE_PORT`, `CHATGPT_BRIDGE_TOKEN` | unset, `5006`, unset | Remote ChatGPT bridge (client / server port / shared secret) |
| `BROWSER_ENGINE`, `BROWSER_HEADLESS`, `BROWSER_HOST`, `BROWSER_PORT`, `BROWSER_REMOTE`, `BROWSER_TOKEN` | `auto`, `1`, `127.0.0.1`, `5006`, unset, unset | Agent browser |
| `BROWSER_ALLOW_PRIVATE`, `BROWSER_DOWNLOAD_DIR`, `BROWSER_MAX_DOWNLOAD_MB` | off, `./downloads`, `200` | Agent browser limits |
| `SKIP_DEPS_CHECK`, `SKIP_BROWSER_DOWNLOAD`, `SKIP_CHROMIUM` | unset | Launcher opt-outs (section 3.1) |

### 10.2 HTTP routes

| Group | Routes |
|---|---|
| Pumps | `POST /fire`, `/start`, `/stop`, `/stopall`, `/selftest`, `/estop/reset`; `GET /status`, `/hardware`, `/flow-status` |
| AI | `POST /ai/chat`, `/ai/chat-stream`, `/ai/recipe`, `/ai/validate-recipe`, `/ai/dispense`, `/ai/voice-stream`, `/ai/configure`; `GET /ai/models`, `/ai/status` |
| ChatGPT website | `POST /ai/browser/open`, `/ai/chatgpt/input`; `GET /ai/browser/status`, `/ai/chatgpt/view.jpg` (this device only) |
| Agent | `POST /agent/chat`, `/aura/llm`; `GET`/`POST /system/volume` |
| Agent browser | `/browse/<op>`, `/browse/capabilities`, `/browse/screenshot`, `/browse/downloads`; `/music/lyrics`, `/music/segments` |
| LCD | `/display`, `/display/api/config`, `/display/api/action`, `/display/api/frame` |
| Settings storage | `GET`/`POST /kiosk/storage` (browser settings mirrored to `data/`) |
| Pages | `/`, `/test`, `/aura`, `/omni/<name>` |

### 10.3 Files

| File | Purpose |
|---|---|
| `backend.py` | Server and pump logic; pluggable Arduino link |
| `usb_transport.py` | Termux USB driver |
| `chatgpt_web.py` | ChatGPT website bridge (Playwright / DevTools / Firefox drivers, three-layer reply reader, sign-in view, remote bridge) |
| `screen_reply.py` | Screenshot analyzer: finds and OCRs only the reply |
| `coda_browser.py` | Browser choice (default / Chrome / Firefox) shared by the bridge, AI browser and launchers |
| `agent.py` | Tool-using agent, AURA pass-through, device volume |
| `agent_browser.py` | The AI's browser (lite and full engines), lyrics, SponsorBlock fallback |
| `display.py`, `display.html`, `display_config.json` | LCD controller, its settings page and saved config |
| `kiosk.html` | The kiosk (faces, subtitles, listening, sounds, settings) |
| `test_mode.html` | Pump test dashboard |
| `aura.html`, `aura_formatting.txt` | AURA workspace console and its formatting rules |
| `omni.js`, `omni.css` | Workspace dock and agent client |
| `player.js`, `player.css` | Music player |
| `ui.js`, `ui.css` | Shared UI layer and Customize drawer |
| `data/` | Saved keys, kiosk settings, ChatGPT profile (created on first run; plain text, keep private) |
| `start.sh`, `start.bat`, `deps.py` | Launchers (with `help`, browser question) and the automatic library checker |
| `termux_setup.sh` | One-shot Termux installer |
| `requirements.txt`, `requirements-desktop.txt` | Core and laptop-only libraries |
| `*.ino`, `ardino flash.txt` | Arduino sketches and flashing notes |
| `logs/` | `start_*.log` per launch and `server.log` |

---

## 11. Troubleshooting

- **ARDUINO NOT FOUND** — the badge and the log say why. Logs: `logs/server.log` and `logs/start_*.log`.
- **Library setup failed** — check your internet connection and run the launcher again, or `python deps.py --force`
  inside the venv. On Debian/Ubuntu you may need `sudo apt install python3-venv`.
- **TV: no USB devices** — check the OTG cable/adapter, close ArduinoDroid, replug, run `bash start.sh probe`.
- **TV: "isn't a chip this backend can drive"** — run `bash start.sh probe` and share the output.
- **"Address already in use"** — an old copy is running: `pkill -9 -f backend.py`. Stop with **Ctrl+C**, never Ctrl+Z.
- **Microphone / keyword listening does nothing** — open the page as `http://localhost:5005` (or HTTPS) in Chrome or
  Edge and allow the microphone. Settings > Listening shows the exact status.
- **ChatGPT website mode fails** — make sure the separate browser is signed in and not showing a check; on Termux use
  the sign-in view; otherwise use the remote bridge. It is a best-effort page reader and can break if the site changes.
- **ChatGPT replied but nothing came back** — set `CHATGPT_DEBUG_DIR=/tmp/gpt` and retry; open `screenshot.png` / `crop.png` there to see what the analyzer saw. Install `tesseract` (Termux: `pkg install tesseract`) or let the launcher install rapidocr.
- **Face or subtitles look stale after an update** — hard-refresh the kiosk page (Ctrl+Shift+R).
